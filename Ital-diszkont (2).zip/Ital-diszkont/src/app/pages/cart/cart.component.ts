import { Injectable } from '@angular/core';
import { Drink } from '../../shared/models/Drink';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  items: {drink: Drink, quantity: number}[] = [];

  constructor() { }

  addItem(drink: Drink) {
    const item = this.items.find(({ drink: itemDrink }) => itemDrink.name === drink.name);
    if (item) {
      item.quantity += 1;
    } else {
      this.items.push({ drink, quantity: 1 });
    }
  }

  removeItem(drink: Drink) {
    const index = this.items.findIndex(({ drink: itemDrink }) => itemDrink.name === drink.name);
    if (index !== -1) {
      const item = this.items[index];
      item.quantity -= 1;
      if (item.quantity === 0) {
        this.items.splice(index, 1);
      }
    }
  }
}
