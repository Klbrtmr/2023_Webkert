import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DrinkComponent } from './drink.component';
//import { DrinkService } from '../../shared/services/drink.service';

@NgModule({
    declarations: [
        DrinkComponent
    ],
    imports: [
        CommonModule,
        RouterModule.forChild([{ path: '', component: DrinkComponent }]),
        FormsModule,
        ReactiveFormsModule,
    ]
})
export class DrinkModule { }