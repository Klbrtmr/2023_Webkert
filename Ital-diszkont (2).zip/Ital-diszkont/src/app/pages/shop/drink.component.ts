import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Drink } from '../../shared/models/Drink';
import { DrinkService } from '../../shared/services/drink.service';
import { CartService } from '../../shared/services/cart.service';
//import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
//import { CartmodalComponent } from '../cartmodal/cartmodal.component';

@Component({
  selector: 'app-drink',
  templateUrl: './drink.component.html',
  styleUrls: ['./drink.component.scss']
})
export class DrinkComponent implements OnInit {
  drinks: Observable<Drink[]> | undefined;

  constructor(
    private drinkService: DrinkService,
    private cartService: CartService,
    //private modalService: NgbModal
  ) {}

  ngOnInit() {
    this.drinks = this.drinkService.getDrinks();
  }

  increment(drink: Drink) {
    drink.quantity++;
    this.drinkService.updateDrinkAvailability(drink);
    this.cartService.items.push({drink, quantity: 1});
  }

  decrement(drink: Drink) {
    if (drink.quantity > 0) {
      drink.quantity--;
      this.drinkService.updateDrinkAvailability(drink);
    }
  }

  addToCart(drink: Drink) {
    this.cartService.addItem(drink);
    /*
    const modalRef = this.modalService.open(CartmodalComponent);
    modalRef.componentInstance.cartItems = this.cartService.items;*/
  }
}
