/*
import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CartService } from '../../shared/services/cart.service';

@Component({
  selector: 'app-cartmodal',
  templateUrl: './cartmodal.component.html',
  styleUrls: ['./cartmodal.component.scss']
})
export class CartmodalComponent {
  @Input() items: {drink: any, quantity: number}[] = [];

  constructor(public activeModal: NgbActiveModal, private cartService: CartService) { }

  onClose(): void {
    this.activeModal.dismiss();
  }

  removeItem(item: {drink: any, quantity: number}): void {
    this.cartService.removeItem(item.drink);
    this.items = this.cartService.items;
  }

  getTotalPrice(): number {
    return this.cartService.getTotalPrice();
  }
}
*/