import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/compat/firestore';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';
import { Drink } from '../models/Drink';


@Injectable({
  providedIn: 'root'
})
export class DrinkService {
  private drinksCollection: AngularFirestoreCollection<Drink>;

  constructor(private db: AngularFirestore, private storage: AngularFireStorage) {
    this.drinksCollection = this.db.collection<Drink>('Drinks');
  }

  getDrinks(): Observable<Drink[]> {
    return this.drinksCollection.valueChanges().pipe(
      map((drinks) => {
        // Transformáljuk a képek URL-jét az "../../assets/" elérési úttal
        return drinks.map((drink) => {
          drink.imageUrl = `../../../assets/${drink.imageUrl}.jpg`;
          return drink;
        });
      })
    );
  }

  updateDrinkAvailability(drink: Drink) {
    this.drinksCollection.doc(drink.name).update({
      isAvailable: drink.quantity > 0
    });
  }
}