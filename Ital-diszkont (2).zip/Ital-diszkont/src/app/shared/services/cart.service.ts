import { Injectable } from '@angular/core';
import { Drink } from '../models/Drink';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  items: {drink: Drink, quantity: number}[] = [];

  constructor() { }

  addItem(drink: Drink, quantity: number = 1) {
    const itemIndex = this.items.findIndex(item => item.drink.name === drink.name);
    if (itemIndex !== -1) {
      this.items[itemIndex].quantity += quantity;
    } else {
      this.items.push({drink, quantity});
    }
  }
  

  removeItem(index: number) {
    this.items.splice(index, 1);
  }

  getItems() {
    return this.items;
  }

  getTotalPrice() {
    return this.items.reduce((total, item) => total + item.quantity * item.drink.price, 0);
  }

  clearCart() {
    this.items = [];
  }
}
