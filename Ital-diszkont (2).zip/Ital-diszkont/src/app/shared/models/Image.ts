export interface Image {
    id: string;
    user_name: string;
    user_url: string;
    photo_url: string;
    image_url: string;
}