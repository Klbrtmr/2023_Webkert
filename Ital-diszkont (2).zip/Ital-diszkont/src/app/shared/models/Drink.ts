export interface Drink {
    name: string;
    price: number;
    imageUrl: string;
    age: number;
    isAvailable: boolean;
    quantity: number;
  }
  