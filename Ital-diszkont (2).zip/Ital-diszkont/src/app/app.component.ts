import { Component, OnInit } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { AuthService } from './shared/services/auth.service';
import { CookieService } from 'ngx-cookie-service';
import { AgeConfirmationDialogComponent } from './pages/age-confirm/age-confirmation-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { CartService } from './shared/services/cart.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  entryComponents: [AgeConfirmationDialogComponent]
})
export class AppComponent implements OnInit {
  page = '';
  routes: Array<string> = [];
  loggedInUser?: firebase.default.User | null;
  location: any;
  dialog: MatDialog;

  constructor(
    private router: Router, 
    private authService: AuthService, 
    private cookieService: CookieService, 
    public matDia: MatDialog, 
    public cartService: CartService
  ) {
    this.dialog = matDia;
  }

  async checkAge() {
    let ageConfirmed = false;
    while (!ageConfirmed) {
      const age = this.cookieService.get('age');
      if (!age || parseInt(age) < 18) {
        // Ha a felhasználó nincs bejelentkezve, vagy nincs 18 éves, akkor megjelenítjük az életkori ellenőrző oldalt.
        const result = await this.showAgeConfirmationDialog();
        if (result) {
          // Ha a felhasználó igazolta, hogy elmúlt 18 éves, mentjük a sütiben az életkorát.
          this.cookieService.set('age', '18');
          ageConfirmed = true;
        }
      } else {
        // Ha a felhasználó már megerősítette, hogy elmúlt 18 éves, kilépünk a ciklusból.
        ageConfirmed = true;
      }
    }
    // Az életkor megerősítése után betöltjük az oldalt.
    this.router.navigateByUrl('/main');
  }

  async showAgeConfirmationDialog() {
    return new Promise<boolean>((resolve) => {
      const dialogRef = this.dialog.open(AgeConfirmationDialogComponent);
      dialogRef.afterClosed().subscribe((result: boolean | PromiseLike<boolean>) => {
        resolve(result);
      });
    });
  }

  ngOnInit() {
    this.routes = this.router.config.map(conf => conf.path) as string[];

    this.checkAge();

    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe((evts: any) => {
      const currentPage = (evts.urlAfterRedirects as string).split('/')[1] as string;
      if (this.routes.includes(currentPage)) {
        this.page = currentPage;
      }
    });

    this.authService.isUserLoggedIn().subscribe(user => {
      this.loggedInUser = user;
      localStorage.setItem('user', JSON.stringify(this.loggedInUser));
    }, error => {
      console.error(error);
      localStorage.setItem('user', JSON.stringify('null'));
    });
  }

  changePage(selectedPage: string) {
    this.router.navigateByUrl(selectedPage);
  }

  onToggleSidenav(sidenav: MatSidenav) {
    sidenav.toggle();
  }

  onClose(event: any, sidenav: MatSidenav) {
    if (event === true) {
      sidenav.close();
    }
  }

  logout(_?: boolean) {
    this.authService.logout().then(() => {
      console.log('Logged out successfully.');
    }).catch(error => {
      console.error(error);
    });
  }
}