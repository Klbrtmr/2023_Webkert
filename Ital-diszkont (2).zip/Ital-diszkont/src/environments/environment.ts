export const environment = {
  firebase: {
      projectId: 'italdiszk',
      appId: '1:120030527087:web:eb4f4eb00aae5e2e2f179a',
      databaseURL: 'https://italdiszk-default-rtdb.europe-west1.firebasedatabase.app',
      storageBucket: 'italdiszk.appspot.com',
      apiKey: 'AIzaSyCfoAV6f9QOd2dyIuZfRlSAkyZ9KfjIuv4',
      authDomain: 'italdiszk.firebaseapp.com',
      messagingSenderId: '120030527087',
      measurementId: 'G-FH1MSJL00N',
  },
  production: true,
  hostUrl: 'http://localhost:4200'
};


